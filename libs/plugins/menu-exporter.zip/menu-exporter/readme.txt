=== WordPress Menu Exporter ===
Contributors: joehoyle, humanmade
Tags: export, menus, exporter, menu
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.0

A plugin taht lets you export only your WordPress menus via the WordPress Export page.

== Description ==

WordPress Menu Exporter lets you only export your WordPress Menus (like you can with Posts, Pages etc). The WordPress Menu Exporter plugin will also export and pages / terms that are referenced in yoru WordPress Menu.

== Installation ==

1. Upload the `menu-exporter` folder to the `/wp-content/plugins/` directory
1. Activate the Menu Exporter plugin through the 'Plugins' menu in WordPress
1. Export your menus via Tools -> Export in the WordPress admin
<?php

return array(
		'tigaaisthemesapi'		=> array(
			'assets' 	=> 'assets',
			'controller'=> TIGAAISTHEMESAPI_BASE_PATH.'app/Controllers/',
			'model'		=> TIGAAISTHEMESAPI_BASE_PATH.'app/Models/'
		),
		'path' 		=> array(
			'view'		=> array(TIGAAISTHEMESAPI_BASE_PATH.'app/Views/')
		),
		'provider' => array(	
			// 'Tiga\Framework\ServiceProvider\AjaxServiceProvider'			
		),
		'alias' 	=> array(
			// 'FooFacade'	=> 'YourApp\Facade\FooFacade'			
		)
	); 
<?php

class Authorization {

	public function check() {

		
		
	}

	public function get() {

		echo '{
		"access_token": "62f6109dcbce42b38f9117b21529faf30fc0ee86",
		"expires_in": 3600,
		"token_type": "Bearer",
		"scope": null
		}';
		
	}

}
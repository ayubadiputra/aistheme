<?php

Routes::get("/tiga-framework","WelcomeController@index");
Routes::get("/get_data","GetData@index");
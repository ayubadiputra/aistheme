<?php

define('TIGA_DEBUG',TRUE);
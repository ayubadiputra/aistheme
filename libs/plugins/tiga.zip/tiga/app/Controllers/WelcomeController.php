<?php
class WelcomeController {

	function index()
	{
		return Response::template('Welcome.php');
	}

	function get_data( $type = false ) {

		/* Get data from database */
		global $wpdb;
		$table 	= $wpdb->prefix . 'posts';

		$args = array(
			'posts_per_page'  	=> 5,
			'offset'           	=> 0,
			'category'         	=> '',
			'category_name'    	=> '',
			'orderby'          	=> 'date',
			'order'            	=> 'DESC',
			'include'          	=> '',
			'exclude'          	=> '',
			'meta_key'         	=> '',
			'meta_value'       	=> '',
			'post_type'        	=> $type,
			'post_mime_type'   	=> '',
			'post_parent'      	=> '',
			'author'	   		=> '',
			'post_status'      	=> 'publish',
			'suppress_filters' 	=> true 
		);
		$posts_array = get_posts( $args );

		return $posts_array;

	}

}
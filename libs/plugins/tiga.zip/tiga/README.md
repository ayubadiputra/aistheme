# tiga - [http://tiga.io](http://tiga.io)
WordPress Faux MVC Framework. Please open issues on [https://github.com/tonjoo/tiga-framework](https://github.com/tonjoo/tiga-framework).

<?php
function tonjoo_display_info(){
	require_once( plugin_dir_path( __FILE__ ) . 'manual.php');
}